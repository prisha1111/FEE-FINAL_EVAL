# Travel-website
Globel Trotter Travelling Agency Website
This repository contains the source code for a Globel Trotter Travelling Website. The application allows users to sign up, browse famous locations, add items to the cart, make successful payments, and more.

Team Members
The development of this application is being carried out by the following team members:

Deployed Link:https://alcazartravelling.netlify.app/

Project Flow : -

Login Page 
![Screenshot 2023-07-08 174400](https://github.com/Shubham10320/Travel-website/assets/68837552/c6db66fb-89fe-465d-b3dc-cd4f2ae1a211)

Home Page
![Screenshot 2023-07-08 174109](https://github.com/Shubham10320/Travel-website/assets/68837552/121e5c3a-76b0-41a0-bbb2-e10bb60dd07f)

Explore Page 
![Screenshot 2023-07-08 174159](https://github.com/Shubham10320/Travel-website/assets/68837552/59c5bd5d-08ec-426e-ab2b-d8033c4238be)

Booking Page
![Screenshot 2023-07-08 174256](https://github.com/Shubham10320/Travel-website/assets/68837552/1f5898c9-45e0-442d-870b-af658ae181c3)





Team Lead: Shubham Chaubey
Task: Home Page and CSS of login and signup
GitHub: Shubham10320

Karan
Task: Implemented google Auth, and product page
GitHub: karank

PreemJeet
Task: Product Page and product description page
GitHub: prem

Kumod Kumar
GitHub: Kumod
Task: RazarPay payment option

WEB Development
To contribute to this project, follow these steps:

We have used HTML CSS JavaScript BootStrap LocalStorage Json-Server FireBase and RazarPay

Entire website is full responsive
